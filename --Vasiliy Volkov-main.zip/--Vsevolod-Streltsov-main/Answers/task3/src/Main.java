

public class Main {
    public static void main(String[] args) {

        SimpleGUI exe = new SimpleGUI();
        exe.setVisible(true);

    }

}
